TABLE 1 - USERS : 

CREATE TABLE users(


username varchar2(25) primary key,
password varchar2(25),
fullname varchar2(25),
role varchar2(20),
mobileNo varchar2(10),
address varchar2(50),
emailId varchar2(30)

);

SELECT * FROM users;

delete from users;
delete from users where username='shweta123';


drop table users cascade constraints;

TABLE 2 - HOTELS :

CREATE TABLE hotels (
hotelId number(4) PRIMARY KEY,
city varchar2(30),
hotelName varchar2(30),
hotelAddress varchar2(30),
hotelDescription varchar2(100),
avgRatePerNight  number(20,10),
phoneNo number(10),
hotelRating varchar2(10),
hotelEmail varchar2(40)
);

create sequence seq_phone_id start with 7548761209 INCREMENT BY 645546;

drop sequence seq_phone_id;

drop table hotels cascade constraints;

create sequence seq_hotel_id start with 1000;

drop sequence seq_hotel_id;
delete from rooms;

insert into hotels values(seq_hotel_id.nextval,'Pune','Ramada','Hinjewadi','MultiLevel Parking with customer pleasing eminities',5000,seq_phone_id.nextval,'****','ramada@ramada.com');

insert into hotels values(seq_hotel_id.nextval,'Delhi','Marriot','Chandni-Chowk','Customer pleasing facilities',7000,seq_phone_id.nextval,'*****','mariot@mariot.com');

insert into hotels values(seq_hotel_id.nextval,'Ahmedabad','Ibis','Satellite','Customer pleasing facilities',10000,seq_phone_id.nextval,'***','ibis@ibis.com');

insert into hotels values(seq_hotel_id.nextval,'Mumbai','Novotel','Church-Gate','Customer pleasing facilities',9000,seq_phone_id.nextval,'**','novotel@novotel.com');

insert into hotels values(seq_hotel_id.nextval,'Banglore','Grand Bay','Whitefield','Customer pleasing facilities',6000,seq_phone_id.nextval,'***','grand@bay.com');

insert into hotels values(seq_hotel_id.nextval,'Chennai','Keys','T Nagar','Customer pleasing facilities',5000,seq_phone_id.nextval,'*****','keys@keys.com');

insert into hotels values(seq_hotel_id.nextval,'Ahmedabad','Courtyard','Paldi','Customer pleasing facilities',7000,seq_phone_id.nextval,'*****','marriot@marriot.com');

insert into hotels values(seq_hotel_id.nextval,'Mumbai','Taj','Ville Parle','Customer pleasing facilities',8600,seq_phone_id.nextval,'*****','taj@tata.com');

insert into hotels values(seq_hotel_id.nextval,'Mumbai','Oberoi','Church-Gate','Customer pleasing facilities',4000,seq_phone_id.nextval,'*****','taj@tata.com');

insert into hotels values(seq_hotel_id.nextval,'Pune','Gulmohar','Hinjewadi','MultiLevel Parking with customer pleasing eminities',10000,seq_phone_id.nextval,'***','gulmohar@greens.com');

SELECT * FROM hotels;

delete from hotels;


TABLE 3 - RoomDetails

CREATE TABLE rooms(
hotel_id number references hotels(hotelId),
room_id number(4) primary key,
room_no varchar2(3),
room_type varchar2(20),
per_night_rate number(20,10),
availability varchar2(5)
);

select * from rooms;

INSERT INTO rooms VALUES(1000,room_id_seq.nextval,'101','Standard Non A\C',2500.25,'TRUE');
INSERT INTO rooms VALUES(1000,room_id_seq.nextval,'102','Standard A\C',3500.25,'TRUE');
INSERT INTO rooms VALUES(1000,room_id_seq.nextval,'103','Executive A\C',4000.50,'TRUE');
INSERT INTO rooms VALUES(1000,room_id_seq.nextval,'104','Deluxe A\C',5500.25,'TRUE');


INSERT INTO rooms VALUES(1001,room_id_seq.nextval,'101','Standard Non A\C',3000.25,'TRUE');
INSERT INTO rooms VALUES(1001,room_id_seq.nextval,'102','Standard A\C',3500.25,'TRUE');
INSERT INTO rooms VALUES(1001,room_id_seq.nextval,'103','Executive A\C',4000.50,'TRUE');
INSERT INTO rooms VALUES(1001,room_id_seq.nextval,'104','Deluxe A\C',5000.25,'TRUE');

INSERT INTO rooms VALUES(1002,room_id_seq.nextval,'101','Standard Non A\C',3300.25,'TRUE');
INSERT INTO rooms VALUES(1002,room_id_seq.nextval,'102','Standard A\C',3500.25,'TRUE');
INSERT INTO rooms VALUES(1002,room_id_seq.nextval,'103','Executive A\C',4200.50,'TRUE');
INSERT INTO rooms VALUES(1002,room_id_seq.nextval,'104','Deluxe A\C',5700.25,'TRUE');

INSERT INTO rooms VALUES(1003,room_id_seq.nextval,'101','Standard Non A\C',2500.25,'TRUE');
INSERT INTO rooms VALUES(1003,room_id_seq.nextval,'102','Standard A\C',3300.25,'TRUE');
INSERT INTO rooms VALUES(1003,room_id_seq.nextval,'103','Executive A\C',4100.50,'TRUE');
INSERT INTO rooms VALUES(1003,room_id_seq.nextval,'104','Deluxe A\C',5600.25,'TRUE');


INSERT INTO rooms VALUES(1004,room_id_seq.nextval,'101','Standard Non A\C',3500.25,'TRUE');
INSERT INTO rooms VALUES(1004,room_id_seq.nextval,'102','Standard A\C',4500.25,'TRUE');
INSERT INTO rooms VALUES(1004,room_id_seq.nextval,'103','Executive A\C',5000.50,'TRUE');
INSERT INTO rooms VALUES(1004,room_id_seq.nextval,'104','Deluxe A\C',5600.25,'TRUE');


INSERT INTO rooms VALUES(1005,room_id_seq.nextval,'101','Standard Non A\C',2700.25,'TRUE');
INSERT INTO rooms VALUES(1005,room_id_seq.nextval,'102','Standard A\C',3500.25,'TRUE');
INSERT INTO rooms VALUES(1005,room_id_seq.nextval,'103','Executive A\C',4400.50,'TRUE');
INSERT INTO rooms VALUES(1005,room_id_seq.nextval,'104','Deluxe A\C',5900.25,'TRUE');


INSERT INTO rooms VALUES(1006,room_id_seq.nextval,'101','Standard Non A\C',3500.25,'TRUE');
INSERT INTO rooms VALUES(1006,room_id_seq.nextval,'102','Standard A\C',4500.25,'TRUE');
INSERT INTO rooms VALUES(1006,room_id_seq.nextval,'103','Executive A\C',5000.50,'TRUE');
INSERT INTO rooms VALUES(1006,room_id_seq.nextval,'104','Deluxe A\C',6500.25,'TRUE');


INSERT INTO rooms VALUES(1007,room_id_seq.nextval,'101','Standard Non A\C',3500.25,'TRUE');
INSERT INTO rooms VALUES(1007,room_id_seq.nextval,'102','Standard A\C',4000.25,'TRUE');
INSERT INTO rooms VALUES(1007,room_id_seq.nextval,'103','Executive A\C',5000.50,'TRUE');
INSERT INTO rooms VALUES(1007,room_id_seq.nextval,'104','Deluxe A\C',6500.50,'TRUE');


INSERT INTO rooms VALUES(1008,room_id_seq.nextval,'101','Standard Non A\C',4000.25,'TRUE');
INSERT INTO rooms VALUES(1008,room_id_seq.nextval,'102','Standard A\C',5000.25,'TRUE');
INSERT INTO rooms VALUES(1008,room_id_seq.nextval,'103','Executive A\C',6000.50,'TRUE');
INSERT INTO rooms VALUES(1008,room_id_seq.nextval,'104','Deluxe A\C',7500.25,'TRUE');


INSERT INTO rooms VALUES(1009,room_id_seq.nextval,'101','Standard Non A\C',4500.25,'TRUE');
INSERT INTO rooms VALUES(1009,room_id_seq.nextval,'102','Standard A\C',5500.25,'TRUE');
INSERT INTO rooms VALUES(1009,room_id_seq.nextval,'103','Executive A\C',6000.50,'TRUE');
INSERT INTO rooms VALUES(1009,room_id_seq.nextval,'104','Deluxe A\C',7500.25,'TRUE');

drop table rooms cascade constraints;

create sequence room_id_seq start with 1000;

drop sequence room_id_seq;

select * from rooms;

DELETE FROM rooms;


Table 4- BookingDetails

drop table BookingDetails cascade constraint;

select * from BookingDetails;

CREATE TABLE BookingDetails(
booking_id number(10) primary key, 
room_id number(10) references ROOMS(room_id),  
username varchar2(50),
booked_from date, 
booked_to date, 
no_of_adults number, 
no_of_children number, 
amount number(30,30)
);
truncate table BookingDetails;

create sequence booking_id_seq start with 1000;
select booking_id_seq.nextval from dual;
drop sequence booking_id_seq;
delete from bookingdetails;

SELECT booking_id_seq.NEXTVAL FROM DUAL
select * from BOOKINGDETAILS;
