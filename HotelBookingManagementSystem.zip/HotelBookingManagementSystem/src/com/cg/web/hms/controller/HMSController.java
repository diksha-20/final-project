package com.cg.web.hms.controller;

import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Date;
import java.util.List;
import java.util.concurrent.TimeUnit;

import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.propertyeditors.CustomDateEditor;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.WebDataBinder;
import org.springframework.web.bind.annotation.InitBinder;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.SessionAttributes;

import com.cg.web.hms.entities.Booking;
import com.cg.web.hms.entities.Hotels;
import com.cg.web.hms.entities.Room;
import com.cg.web.hms.entities.Users;
import com.cg.web.hms.exception.HBMSException;
import com.cg.web.hms.service.AdminService;
import com.cg.web.hms.service.BookingService;
import com.cg.web.hms.service.RoomBookingService;
import com.cg.web.hms.service.UserService;
import com.sun.scenario.effect.Blend.Mode;

@Controller
@SessionAttributes("users")
public class HMSController {
	
	@Autowired
	private UserService userService;

	@Autowired
	private RoomBookingService roomBookingService;
	
	@Autowired
	private BookingService bookingService;
	
	Users user;
	Hotels hotel;
	Room room;
	
	
	public BookingService getBookingService() {
		return bookingService;
	}

	public void setBookingService(BookingService bookingService) {
		this.bookingService = bookingService;
	}

	public RoomBookingService getRommBookingService() {
		return roomBookingService;
	}

	public void setRommBookingService(RoomBookingService rommBookingService) {
		this.roomBookingService = rommBookingService;
	}

	public UserService getUserService() {
		return userService;
	}

	public void setUserService(UserService userService) {
		this.userService = userService;
	}
	
	//Default Constructor of the class
	public HMSController() {
		//Creating new Instances of Objects used
		user = new Users();
		hotel = new Hotels();
		room = new Room();
		
	}

	//For the hyper link of Home
	@RequestMapping("/Homepage.mvc")
	public String displayHomePage(Model model) {
		model.addAttribute("sessionVar",user);
		List<Hotels> hotelList = new ArrayList<>();
		try {
			hotelList = userService.viewAllHotels();

			model.addAttribute("sessionVar",user);
			model.addAttribute("list",hotelList);
			return "HotelList";
		
		
		} catch (HBMSException e) {
			
          System.out.println("Error Occured. Reason : "+e.getMessage());
			
			return "index";
		}
	}
	
	//Displaying Login page 
	@RequestMapping("/index.mvc")
	public String getIndexPage(Model model) {
		
		model.addAttribute("users",new Users());
		return "index";
		
	}
	
	//List for the radiobutton for signup
	private List<String> getRoleList() {
		return Arrays.asList("Customer","Administrator");
	}
	
	
	//Redirect to signup page from Login page
	@RequestMapping("/SignUp.mvc")
	public String getSignUpPage(Model model) {
		
		model.addAttribute("roleList",getRoleList());
		model.addAttribute("userData",new Users());
		
		return "SignUp";
	}
	
	
	//Display HotelList after Authentication
	@RequestMapping("/ProcessLoginForm.mvc")
	public String processLoginPage(
			@ModelAttribute("users") Users userData,
			Model model
			) {
		
		Users users = new Users();
		List<Hotels> hotelList = new ArrayList<>();
		
		try {
			
			users = userService.validateUser(userData.getUsername(),userData.getPassword());
			model.addAttribute("users",users);
			hotelList = userService.viewAllHotels();
			model.addAttribute("list",hotelList);
			if(users!=null && users.getRole().equals("Customer")) {
				
				//If user is customer then redirect to the HotelList
				return "HotelList";
					
			}else if(users!=null && users.getRole().equals("Administrator")) {
				
				//If user is Admin then redirect to the Admin Home page
				return "AdminHome";
				
			}else {
				//If authentication fails
				model.addAttribute("msg","Invalid Credentials. Please Sign In again.");
				
			}
			
			return "index";
			
		} catch (HBMSException e) {
			
			model.addAttribute("msg", "Invalid Credentials. Please Sign In again.");
			return "index";
			
		} catch(Exception e) {
			
			model.addAttribute("msg", "Invalid Credentials. Please Sign In again.");
			return "index";
			
		}
		
	}
	
	//Adding user after signingup
	@RequestMapping(value="/ProcessSignUpForm.mvc",method=RequestMethod.POST)
	public String processSignUpForm(
			@ModelAttribute("userData") @Valid Users userData,
			BindingResult binding,
			Model model) {
		
		if(binding.hasErrors()) {
			model.addAttribute("msg","Error Occured. Sign Up Rolled Back.");
			model.addAttribute("roleList",getRoleList());
			return "SignUp";
		}
		
		try {
			user = userService.addUser(userData);
			model.addAttribute("username",userData.getFullname());
			return "index";
		} catch (HBMSException e) {
			model.addAttribute("msg","Some Error Occured.");
			model.addAttribute("roleList",getRoleList());
			return "SignUp";
		} catch (Exception e) {
			model.addAttribute("msg","Some Error Occured");
			model.addAttribute("roleList",getRoleList());
			return "SignUp";
		}
		
	}
	
	//Displaying available Room list
	@RequestMapping(value="/ProcessBooking.mvc",method=RequestMethod.POST)
	public String processBooking(
			@RequestParam("hotelId") int hotelId,
			@ModelAttribute("users") Users user,
			Model model
			) {
		
		List<Room> rooms; 
		try {
			hotel = userService.searchHotelById(hotelId);
			model.addAttribute("hotel",hotel);
			rooms = roomBookingService.getAllRoomDetails(hotelId);

			model.addAttribute("users",user);
			model.addAttribute("roomData",rooms);
			if(rooms.isEmpty()) {
				model.addAttribute("msg","No Rooms Avavilable. Please check our other branches. Thank You "+user.getFullname()+". Please Visit Soon..");
			}
			return "Booking";
		} catch (HBMSException e) {
			model.addAttribute("msg","Something Went Wrong.");
			return "HotelList";
		}
	}
	
	//Filter the hotel list by city
	@RequestMapping(value="/SearchByCity.mvc",method=RequestMethod.POST)
	public String searchByCity(
			@RequestParam("city") String city,
			Model model
			) {
		
		try {
			List<Hotels> hotel = userService.searchHotelByCity(city);
			if(hotel.isEmpty()) {
				model.addAttribute("msg","Please Enter Valid City. No Hotels Avavilable");
				hotel = userService.viewAllHotels();
			}
			model.addAttribute("list",hotel);
		} catch (HBMSException e) {
			model.addAttribute("msg","Something went wrong");
		}
		
		return "HotelList";
		
	}
	
	//Display Room Booking Form After selecting a particular room 
	@RequestMapping(value="/GetRoomBookingForm.mvc",method=RequestMethod.POST)
	public String getBookingForm(
			@ModelAttribute("users") Users user,
			@RequestParam("roomId") int roomId,
			Model model
			) {

		double amount=0;
		String userName=user.getFullname();		
		
		Booking booking = new Booking();
		
		booking.setRoomId(roomId);
		booking.setUserName(userName);
		
	
		try {
			amount = bookingService.getRoomAmount(roomId);
			
			booking.setAmount(amount);
		
		} 
		catch (HBMSException e) {
			
			model.addAttribute("errMsg", "Something went wrong while booking form" + e.getMessage());
			return "ErrorPage";
		}
		catch (Exception e) {
			
			model.addAttribute("errMsg", "Something went wrong while booking form" + e.getMessage());
			return "ErrorPage";
		}
		
		
		model.addAttribute("bookingData", booking);
		
		return "BookingForm";
	}
	
	//Registering Booking of the room. And changing its availibility
	@RequestMapping("/ProcessRoomBookingForm")
	public String processBookingForm(
			@ModelAttribute("bookingData") @Valid Booking booking,
			BindingResult bindingResult,
			Model model)
	{
		
		
		if (bindingResult.hasErrors()) 
		{
			return "BookingForm";
		}
		
		try 
		{
			Date checkOutDate,checkInDate; 
			checkInDate=booking.getBookedFrom();
			booking.setBookedFrom(checkInDate);
			checkOutDate=booking.getBookedTo();

			booking.setBookedTo(checkOutDate);
			
            if(!checkOutDate.after(checkInDate)){
            	
            	model.addAttribute("bookingData", booking);
    			model.addAttribute("dateErr", "*Check-In Date Should be before Check-Out Date");
    			return "BookingForm";
            }

            
            Date d = new Date();
            if(!checkInDate.after(d)){
            	model.addAttribute("bookingData", booking);
    			model.addAttribute("dateErr1", "*Check-In Date Should be after Today");
    			return "BookingForm";
            }
            
            if(booking.getNoOfAdults()>4 || booking.getNoOfAdults()<1){
            	model.addAttribute("bookingData", booking);
    			model.addAttribute("NoOfAdultErr", "*No Of Adults Should be 1 to 4");
    			return "BookingForm";
            }
            
            if(booking.getNoOfChildren()>4 || booking.getNoOfAdults()<0){
            	model.addAttribute("bookingData", booking);
    			model.addAttribute("NoOfChildErr", "*No Of Children Should be Less Than 5");
    			return "BookingForm";
            }
            
			long difference=checkOutDate.getTime()-checkInDate.getTime();

			System.out.println("difference="+difference);
			
			long days=TimeUnit.DAYS.convert(difference, TimeUnit.MILLISECONDS) ;	
			System.out.println("dayes ="+days);
			double totalAmount=booking.getAmount()*Double.parseDouble(days+"");
			
			booking.setAmount(totalAmount);
			System.out.println("Amount ="+totalAmount);
			
			int bookingId = bookingService.addBookingDetails(booking);
				
			
			//To Change room availability status
			
			bookingService.changeRoomAvailability(booking.getRoomId());
			
			
			
			    model.addAttribute("totalAmount", totalAmount);
				model.addAttribute("bookingId", bookingId);
				model.addAttribute("booking", booking);
				System.out.println(booking);
				return "SuccessPage";

		 		
		} 
		catch (HBMSException e) {
			
			model.addAttribute("errMsg", "Something went wrong while booking room" + e.getMessage());
			return "ErrorPage";
		}
		catch (Exception e) {
			
			model.addAttribute("errMsg", "Something went wrong while booking room" + e.getMessage());
			return "ErrorPage";
		}

	}
	
	//Describing Date Formatter.
	@InitBinder("bookingData")
	public void customizeBinding(WebDataBinder binder) {
		
		SimpleDateFormat dateFormatter = new SimpleDateFormat("dd-MM-yyyy");
		
		dateFormatter.setLenient(false);
		
		binder.registerCustomEditor(Date.class, "bookedFrom", new CustomDateEditor(dateFormatter, true));
		
		binder.registerCustomEditor(Date.class, "bookedTo", new CustomDateEditor(dateFormatter, true));
		
	}
	
	
	//-------------------------ADMIN-----------------//
		@Autowired
		AdminService adminService;

		public AdminService getAdminService() {
			return adminService;
		}

		public void setAdminService(AdminService adminService) {
			this.adminService = adminService;
		}
		
		/*@RequestMapping("/GetAdminPage.mvc")
		public String getAdminHomePage(@RequestParam("username") String name, Model model)
		{
			model.addAttribute("username",name);
			
			
			
			return "AdminHome";
		}*/
		
		public List<String> getStarList(){
			return Arrays.asList("*","**","***","****","*****");
		}
		
		public List<String> getAvailabilityList(){
			return Arrays.asList("True","False");
		}
		
		public List<String> getRoomTypeList(){
			return Arrays.asList("Standard Non A\\C","Standard A\\C","Executive A\\C","Deluxe A\\C");
		}
		
		//Redirecting to a Form for Adding Hotel
		@RequestMapping(value="/AddHotel.mvc",method=RequestMethod.POST)
		public String getAddHotelPage(
				@ModelAttribute("users") Users user,
				Model model)
		{
			
			model.addAttribute("users",user);
			model.addAttribute("starlist",getStarList());
			model.addAttribute("hotel",new Hotels());
			return "AddHotel";
			
		}
		
		//Processing Adding Hotel Form
		@RequestMapping(value="/ProcessAddHotelForm.mvc", method=RequestMethod.POST)
		public String processAddHotelForm(
				@ModelAttribute("users") Users user,
				@ModelAttribute("hotel") @Valid Hotels hotel,
				BindingResult bindingResult,
				Model model
				)
		{
			if(bindingResult.hasErrors())
			{
				model.addAttribute("starlist",getStarList());
				return "AddHotel";
			}
			
			try {
				
				//int traineeId = traineeService.addTrainee(trainee);
				int id = adminService.addHotel(hotel);
				System.out.println("ppppppppp"+id);
				//model.addAttribute("hotelId",id);
				model.addAttribute("hotel",new Hotels());
				model.addAttribute("users",user);
				model.addAttribute("message", "Hotel Details Added Succesfully for ID: "+hotel.getHotelId());
				//model.addAttribute("starlist",getStarList());
				return "AdminSuccess";
				
			} catch (HBMSException e) {
				model.addAttribute("errMsg","Something went wrong while trying to add hotel details. Reason:"+e.getMessage());
				return "ErrorPage";
				
			} catch (Exception e) {
				model.addAttribute("errMsg","Something went wrong. Contact Admin");
				return "ErrorPage";
			}
			
			
		}
		
		//Updating Hotel Details
		@RequestMapping(value="/UpdateHotel.mvc")
		public String getUpdateHotelPage(){
			
			return "UpdateHotel";
		}
		
		//Redirecting to Update Hotel Form
		@RequestMapping(value="/GetUpdateHotelPage.mvc", method=RequestMethod.POST)
		public String getUpdateHotelPage(@RequestParam("hotelId") String id, Model model){
			
			System.out.println("\n\n\n\n"+id);
			
			Hotels hotel = null;
			try {
				//adminService.updateHotel(hotel);
				hotel=adminService.viewHotel(Integer.parseInt(id));
				//model.addAttribute("message","Hotel details Updated Successfully for ID: "+hotel.getHotelId());
				model.addAttribute("hotel",hotel);
				model.addAttribute("starlist",getStarList());
				
				return "UpdateHotel";
				
			}  catch (HBMSException e) {
				model.addAttribute("errMsg","Something went wrong while trying to update hotel details. Reason:"+e.getMessage());
				return "ErrorPage";
				
			} catch (Exception e) {
				model.addAttribute("errMsg","Something went wrong. Contact Admin");
				return "ErrorPage";
			}
			
		}

		//Processing Updated Details and Reflecting them in the database
		@RequestMapping(value="/ProcessUpdateHotelDetails.mvc", method=RequestMethod.POST)
		public String processUpdateEmployeeDetails(@ModelAttribute("hotel") @Valid Hotels hotel, BindingResult bindingResult, Model model )
		{
			if(bindingResult.hasErrors())
			{
				model.addAttribute("starlist",getStarList());
				return "UpdateHotel";
			}
			
			try {
				adminService.updateHotel(hotel);
				
				model.addAttribute("message", "Hotel Details Updated Succesfully for ID: "+hotel.getHotelId());
				//model.addAttribute("starlist",getStarList());
				return "AdminSuccess";
				
			} catch(HBMSException e){
				model.addAttribute("errMsg","Something went Wrong while trying to update Hotel Details. Reason: "+e.getMessage());
				return "ErrorPage";
			} catch(Exception e){
				model.addAttribute("errMsg","Something went Wrong .Please contact the admimnistrator. Reason: "+e.getMessage());
				return "ErrorPage";
			}
		}

//		
//		@RequestMapping("/GetAdminPage.mvc")
//		public String getViewAllHotelsPage(@RequestParam("username") String name,Model model)
//		{
//			
//			System.out.println("\n\n\n"+name);
//			model.addAttribute("username",name);
//			try{
//				List<Hotels> hotels = adminService.viewAllHotels();
//				model.addAttribute("hotels",hotels);
//				return "AdminHome";
//			}catch (HBMSException e) {
//				model.addAttribute("errMsg","Something went wrong while trying to fetch hotel details. Reason:"+e.getMessage());
//				return "ErrorPage";
//				
//			} catch (Exception e) {
//				model.addAttribute("errMsg","Something went wrong. Contact Admin");
//				return "ErrorPage";
//			}
//		}
		
		
//		@RequestMapping(value="/GetRemoveHotelPage.mvc", method=RequestMethod.POST)
//		public String getRemoveHotelPage(){
//			return "RemoveHotel";
//		}
		
		//Removing Hotel by Hotel Id
		@RequestMapping(value="/ProcessRemoveHotelForm.mvc")
		public String processRemoveHotelForm(@RequestParam("hotelId")int id,Model model)
		{
			
			Hotels hotel=new Hotels();
			System.out.println("\n\n\n"+id);
			try {
				
				hotel = adminService.deleteHotel(id);
				model.addAttribute("message", "Hotel Details Deleted Succesfully for ID: "+hotel.getHotelId());
				//model.addAttribute("hotel",employee);
				
			} catch(HBMSException e){
				model.addAttribute("errMsg","Something went Wrong while trying to delete Hotel Details. Reason: "+e.getMessage());
				return "ErrorPage";
			} catch(Exception e){
				model.addAttribute("errMsg","Something went Wrong .Please contact the administrator. Reason: "+e.getMessage());
				return "ErrorPage";
			}
			return "AdminSuccess";
		}
		
		// View Room for the particular hotel by forwarding its hotel id
		@RequestMapping(value="/ViewRoomsById.mvc")
		public String getViewAllRoomsPage(@RequestParam("hotelId") String hotelId,Model model)
		{
			List<Room> rooms=null;
			Hotels hotel=null;
			try {
				rooms=adminService.getAllRoomDetails(Integer.parseInt(hotelId));
				hotel=adminService.viewHotel(Integer.parseInt(hotelId));
				model.addAttribute("roomData",rooms);
				model.addAttribute("hotel",hotel);
				
				System.out.println(rooms);
			} catch(HBMSException e){
				model.addAttribute("errMsg","Something went Wrong while trying to view room Details. Reason: "+e.getMessage());
				return "ErrorPage";
			} catch(Exception e){
				model.addAttribute("errMsg","Something went Wrong .Please contact the administrator. Reason: "+e.getMessage());
				return "ErrorPage";
			}
			return "ViewRooms";
		}
		
		//Redirecting to the form for Adding a room.
		@RequestMapping("/AddRoom.mvc")
		public String getAddRoomPage(@RequestParam("hotelId") String hotelId,Model model)
		{
			
			;
			model.addAttribute("hotelId",Integer.parseInt(hotelId));
			model.addAttribute("avaibilityList",getAvailabilityList());
			model.addAttribute("roomTypeList",getRoomTypeList());
			model.addAttribute("room",new Room());
			return "AddRoom";
		}
		
		//Storing in the database and displaying the added room for user
		@RequestMapping(value="/ProcessAddRoomForm.mvc", method=RequestMethod.POST)
		public String processAddRoomForm(@RequestParam("hotelId") String hotelId,@ModelAttribute("room") @Valid Room room,BindingResult bindingResult, Model model)
		{
			if(bindingResult.hasErrors())
			{
				model.addAttribute("starlist",getStarList());
				return "AdminSuccess";
			}
			
			try {
				
				room.setHotelId(Integer.parseInt(hotelId));
				
				//int traineeId = traineeService.addTrainee(trainee);
				int roomid = adminService.addRoom(room);
				//model.addAttribute("hotelId",id);
				model.addAttribute("hotel",new Hotels());
				model.addAttribute("message", "Room Succesfully Added with roomID: "+room.getRoomId());
				//model.addAttribute("starlist",getStarList());
				return "AdminSuccess";
				
			} catch (HBMSException e) {
				model.addAttribute("errMsg","Something went wrong while trying to add hotel details. Reason:"+e.getMessage());
				return "ErrorPage";
				
			} catch (Exception e) {
				model.addAttribute("errMsg","Something went wrong. Contact Admin");
				return "ErrorPage";
			}
			
			
		}
}
