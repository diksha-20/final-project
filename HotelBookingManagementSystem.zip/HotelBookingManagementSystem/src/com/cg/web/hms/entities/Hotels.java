package com.cg.web.hms.entities;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.SequenceGenerator;
import javax.persistence.Table;
import javax.validation.constraints.Min;
import javax.validation.constraints.Pattern;

import org.hibernate.validator.constraints.NotEmpty;

@Entity
@Table(name="hotels")
public class Hotels {
	
	@Id
	@SequenceGenerator(name="seq",sequenceName="seq_hotel_id",allocationSize=1)
	@GeneratedValue(strategy=GenerationType.SEQUENCE,generator="seq")
	private int hotelId;
	
	@NotEmpty(message="City should not be empty.")
	private String city;
	
	@NotEmpty(message="Hotel Name should not be empty")
	private String hotelName;
	
	@NotEmpty(message="Hotel Address should not be empty")
	private String hotelAddress;
	
	@NotEmpty(message="Description should not be empty")
	private String hotelDescription;
	
	@Min(value=1000,message="Amount should be greater than 1000")
	private double avgRatePerNight;
	
	@Pattern(regexp="[7-9][0-9]{9}",message="Phone Number should start with 7,8 or 9 and should be of 10 digits.")
	private String phoneNo;
	
	@NotEmpty(message="Rating should not be empty")
	private String hotelRating;
	
	@Pattern(regexp="[a-z0-9_.]+@[a-z]{3,10}.[a-z]{2,3}",message="Email not valid. Should be in small letters and only '_' & '.' special character allowed. Eg: abc_adc@abc.com, abc@abc.in.")
	private String hotelEmail;
	
	
	public int getHotelId() {
		return hotelId;
	}
	public void setHotelId(int hotelId) {
		this.hotelId = hotelId;
	}
	public String getCity() {
		return city;
	}
	public void setCity(String city) {
		this.city = city;
	}
	public String getHotelName() {
		return hotelName;
	}
	public void setHotelName(String hotelName) {
		this.hotelName = hotelName;
	}
	public String getHotelAddress() {
		return hotelAddress;
	}
	public void setHotelAddress(String hotelAddress) {
		this.hotelAddress = hotelAddress;
	}
	public String getHotelDescription() {
		return hotelDescription;
	}
	public void setHotelDescription(String hotelDescription) {
		this.hotelDescription = hotelDescription;
	}
	public double getAvgRatePerNight() {
		return avgRatePerNight;
	}
	public void setAvgRatePerNight(double avgRatePerNight) {
		this.avgRatePerNight = avgRatePerNight;
	}
	public String getPhoneNo() {
		return phoneNo;
	}
	public void setPhoneNo(String phoneNo) {
		this.phoneNo = phoneNo;
	}
	public String getHotelRating() {
		return hotelRating;
	}
	public void setHotelRating(String hotelRating) {
		this.hotelRating = hotelRating;
	}
	public String getHotelEmail() {
		return hotelEmail;
	}
	public void setHotelEmail(String hotelEmail) {
		this.hotelEmail = hotelEmail;
	}
	
	
	
}
