package com.cg.web.hms.entities;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.SequenceGenerator;
import javax.persistence.Table;
import javax.persistence.Transient;
import javax.persistence.UniqueConstraint;
import javax.validation.constraints.Pattern;

import org.hibernate.validator.constraints.NotEmpty;

@Entity
@Table(name="users")
public class Users {
	

	/*@Column(name="userid")
	@SequenceGenerator(name="user_id",sequenceName="seq_user_id" , allocationSize=1)
	@GeneratedValue(strategy=GenerationType.SEQUENCE,generator="user_id")
	private int userid;
	*/
	@Id
	private String username;
	
	@NotEmpty(message="*")
	private String fullname;
	
	@NotEmpty(message="*")
	private String password;
	
	@NotEmpty(message="*")
	private String role;
	
	@Pattern(regexp="[7-9][0-9]{9}",message="*")
	private String mobileNo;
	
	private String address;
	
	@Pattern(regexp="[a-z0-9_.]+@[a-z]{3,10}.[a-z]{2,3}",message="*")
	private String emailId;
	
	@Transient
	private String confirmPassword;
	
	public String getConfirmPassword() {
		return confirmPassword;
	}
	public void setConfirmPassword(String confirmPassword) {
		this.confirmPassword = confirmPassword;
	}
	/*public int getUserid() {
		return userid;
	}
	public void setUserid(int userid) {
		this.userid = userid;
	}*/
	public String getUsername() {
		return username;
	}
	public void setUsername(String username) {
		this.username = username;
	}
	public String getFullname() {
		return fullname;
	}
	public void setFullname(String fullname) {
		this.fullname = fullname;
	}
	public String getPassword() {
		return password;
	}
	public void setPassword(String password) {
		this.password = password;
	}
	public String getRole() {
		return role;
	}
	public void setRole(String role) {
		this.role = role;
	}
	public String getMobileNo() {
		return mobileNo;
	}
	public void setMobileNo(String mobileNo) {
		this.mobileNo = mobileNo;
	}
	public String getAddress() {
		return address;
	}
	public void setAddress(String address) {
		this.address = address;
	}
	public String getEmailId() {
		return emailId;
	}
	public void setEmailId(String emailId) {
		this.emailId = emailId;
	}
	
	

}
