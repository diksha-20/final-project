package com.cg.web.hms.entities;

import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.SequenceGenerator;
import javax.persistence.Table;
import javax.validation.constraints.NotNull;


@Entity
@Table(name="BookingDetails")
public class Booking {


	@Id
	@Column(name="booking_id")
	@SequenceGenerator(name="seqBookingId", sequenceName="booking_id_seq",allocationSize=1)
	@GeneratedValue(strategy=GenerationType.SEQUENCE, generator="seqBookingId")
	private int BookingId;
	
	@Column(name="room_id")
	private int roomId;
	
	@Column(name="username")
	private String userName;
	
	@Column(name="booked_from")
	@NotNull(message="*")
	private Date bookedFrom;
	
	@Column(name="booked_to")
	@NotNull(message="*")
	private Date bookedTo;
	
	@Column(name="no_of_adults")
	@NotNull(message="*")
	private int noOfAdults;
	
	@Column(name="no_of_children")
	private int noOfChildren;
	
	@Column(name="amount")
	private double amount;

	public Booking() {
		super();
		// TODO Auto-generated constructor stub
	}

	public Booking(int bookingId, int roomId, String userName, Date bookedFrom,
			Date bookedTo, int noOfAdults, int noOfChildren, double amount) {
		super();
		BookingId = bookingId;
		this.roomId = roomId;
		this.userName = userName;
		this.bookedFrom = bookedFrom;
		this.bookedTo = bookedTo;
		this.noOfAdults = noOfAdults;
		this.noOfChildren = noOfChildren;
		this.amount = amount;
	}

	public Booking(int roomId, String userName, Date bookedFrom, Date bookedTo,
			int noOfAdults, int noOfChildren, double amount) {
		super();
		this.roomId = roomId;
		this.userName = userName;
		this.bookedFrom = bookedFrom;
		this.bookedTo = bookedTo;
		this.noOfAdults = noOfAdults;
		this.noOfChildren = noOfChildren;
		this.amount = amount;
	}

	public int getBookingId() {
		return BookingId;
	}

	public void setBookingId(int bookingId) {
		BookingId = bookingId;
	}

	public int getRoomId() {
		return roomId;
	}

	public void setRoomId(int roomId) {
		this.roomId = roomId;
	}

	public String getUserName() {
		return userName;
	}

	public void setUserName(String userName) {
		this.userName = userName;
	}

	public Date getBookedFrom() {
		return bookedFrom;
	}

	public void setBookedFrom(Date bookedFrom) {
		this.bookedFrom = bookedFrom;
	}

	public Date getBookedTo() {
		return bookedTo;
	}

	public void setBookedTo(Date bookedTo) {
		this.bookedTo = bookedTo;
	}

	public int getNoOfAdults() {
		return noOfAdults;
	}

	public void setNoOfAdults(int noOfAdults) {
		this.noOfAdults = noOfAdults;
	}

	public int getNoOfChildren() {
		return noOfChildren;
	}

	public void setNoOfChildren(int noOfChildren) {
		this.noOfChildren = noOfChildren;
	}

	public double getAmount() {
		return amount;
	}

	public void setAmount(double amount) {
		this.amount = amount;
	}

	@Override
	public String toString() {
		return "Booking [BookingId=" + BookingId + ", roomId=" + roomId
				+ ", userName=" + userName + ", bookedFrom=" + bookedFrom
				+ ", bookedTo=" + bookedTo + ", noOfAdults=" + noOfAdults
				+ ", noOfChildren=" + noOfChildren + ", amount=" + amount + "]";
	}


	
	
}
