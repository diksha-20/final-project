package com.cg.web.hms.entities;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.SequenceGenerator;
import javax.persistence.Table;

@Entity
@Table(name="rooms")
public class Room 
{
	@Id
	@Column(name="room_id")
	@SequenceGenerator(name="seq1",sequenceName="room_id_seq")
	@GeneratedValue(strategy=GenerationType.SEQUENCE,generator="seq1")
	private int roomId;
	
	@Column(name="hotel_id")
	private int hotelId;
	
	@Column(name="room_no")
	private String roomNo;
	
	@Column(name="room_type")
	private String roomType;
	
	@Column(name="per_night_rate")
	private double ratePerNight;
	
	@Column(name="availability")
	private String avaibility;
	
	
	public Room(int hotelId, int roomId, String roomNo, String roomType,
			double ratePerNight, String avaibility) 
	{
		super();
		this.hotelId = hotelId;
		this.roomId = roomId;
		this.roomNo = roomNo;
		this.roomType = roomType;
		this.ratePerNight = ratePerNight;
		this.avaibility = avaibility;
	}
	
	
	
	public Room(int hotelId, String roomNo, String roomType,
			double ratePerNight, String avaibility) {
		super();
		this.hotelId = hotelId;
		this.roomNo = roomNo;
		this.roomType = roomType;
		this.ratePerNight = ratePerNight;
		this.avaibility = avaibility;
	}



	public Room() {
		super();
	}
	
	@Override
	public String toString() 
	{
		return "RoomData [hotelId=" + hotelId + ", roomId=" + roomId
				+ ", roomNo=" + roomNo + ", roomType=" + roomType
				+ ", ratePerNight=" + ratePerNight + ", avaibility="
				+ avaibility + "]";
	}
	
	public int getHotelId() {
		return hotelId;
	}
	public void setHotelId(int hotelId) {
		this.hotelId = hotelId;
	}
	public int getRoomId() {
		return roomId;
	}
	public void setRoomId(int roomId) {
		this.roomId = roomId;
	}
	public String getRoomNo() {
		return roomNo;
	}
	public void setRoomNo(String roomNo) {
		this.roomNo = roomNo;
	}
	public String getRoomType() {
		return roomType;
	}
	public void setRoomType(String roomType) {
		this.roomType = roomType;
	}
	public double getRatePerNight() {
		return ratePerNight;
	}
	public void setRatePerNight(double ratePerNight) {
		this.ratePerNight = ratePerNight;
	}
	public String getAvaibility() {
		return avaibility;
	}
	public void setAvaibility(String avaibility) {
		this.avaibility = avaibility;
	}

}
