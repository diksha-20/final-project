package com.cg.web.hms.exception;

public class HBMSException extends Exception {

	public HBMSException() {
		
	}

	public HBMSException(String message) {
		super(message);
		
	}

	public HBMSException(Throwable cause) {
		super(cause);
		
	}

	public HBMSException(String message, Throwable cause) {
		super(message, cause);
		
	}

	public HBMSException(String message, Throwable cause,
			boolean enableSuppression, boolean writableStackTrace) {
		super(message, cause, enableSuppression, writableStackTrace);
		
	}

}
