package com.cg.web.hms.dao;

import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.TypedQuery;

import org.springframework.stereotype.Repository;

import com.cg.web.hms.entities.Hotels;
import com.cg.web.hms.entities.Room;
import com.cg.web.hms.exception.HBMSException;


@Repository
public class AdminDAOImpl implements AdminDAO {


	@PersistenceContext
	private EntityManager entityManager;	
	
	public EntityManager getEntityManager() {
		return entityManager;
	}

	public void setEntityManager(EntityManager entityManager) {
		this.entityManager = entityManager;
	}
	
	
	

	@Override
	public int addHotel(Hotels hotel) throws HBMSException {
		
		int hotelId=0;
		
		try 
		{
			
			entityManager.persist(hotel);
			entityManager.flush();
			
			hotelId = hotel.getHotelId(); 
			
		} catch (Exception e) {
			throw new HBMSException(e);
		}
		return hotelId;
	}

	@Override
	public void updateHotel(Hotels hotel) throws HBMSException {

		try {
			entityManager.merge(hotel);
			entityManager.flush();
			
			
		} catch (Exception e) {
			throw new HBMSException(e);
		} 
	}

	@Override
	public Hotels deleteHotel(int id) throws HBMSException {
		
		Hotels hotel= null;
		
		try {
			
			
			hotel=entityManager.find(Hotels.class, id);
			
			if(hotel==null)
				throw new Exception("Hotel with id not found");
			
			entityManager.remove(hotel);
			entityManager.flush();
			
			
		} catch (Exception e) {
			throw new HBMSException(e);
		}
		
		return hotel;
	}

	@Override
	public Hotels viewHotel(int id) throws HBMSException {
		
		Hotels hotel= null;
		
		try {
			hotel=entityManager.find(Hotels.class, id);
			
			if(hotel==null)
				throw new Exception("Hotel with id not found");
			entityManager.flush();
			
		} catch (Exception e) {
			throw new HBMSException(e);
		}
		
		return hotel;
	}

	@Override
	public List<Hotels> viewAllHotels() throws HBMSException {
		List<Hotels> hotels=null;
		
		try {
			
			String query = "select hotels from Hotel hotels";
			TypedQuery<Hotels> tQuery = entityManager.createQuery(query, Hotels.class);
			
			hotels=tQuery.getResultList();
			
		} catch (Exception e) {
			throw new HBMSException(e);
		}
		
		return hotels;
	}
	
	@Override
	public List<Room> getAllRoomDetails(int hotelId) throws HBMSException {
		List<Room> rooms;
		
		String sql = "SELECT roomData from Room roomData where roomData.hotelId=?";
		
		TypedQuery<Room> tQuery=entityManager.createQuery(sql,Room.class);
		
		tQuery.setParameter(1, hotelId);
		
		rooms=tQuery.getResultList();
		
		return rooms;
	}

	@Override
	public int addRoom(Room room) throws HBMSException {
		int roomId=0;
		
		try 
		{
			entityManager.persist(room);
			
			
			roomId = room.getRoomId(); 
		} catch (Exception e) {
			throw new HBMSException(e);
		}
		
		return roomId;
	}

}