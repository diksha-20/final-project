package com.cg.web.hms.dao;

import java.util.List;

import com.cg.web.hms.entities.Hotels;
import com.cg.web.hms.entities.Users;
import com.cg.web.hms.exception.HBMSException;

public interface UserDao {
	
	/************************************************************************************
	 * File:        UserDao.java
	 * Package:     com.cg.web.hms.dao
	 * Desc:        Validate the user at the time of Login
	 * Version:     1.0
	 * Author: Shweta Gaikwad
	 ************************************************************************************/

	public Users validateUser(String username,String password) throws HBMSException;
	
	/************************************************************************************
	 * File:        UserDao.java
	 * Package:     com.cg.web.hms.dao
	 * Desc:        Register New User details
	 * Version:     1.0
	 * Author: Saloni Nagaria
	 ************************************************************************************/
	public Users addUser(Users user) throws HBMSException;

	
	/************************************************************************************
	 * File:        UserDao.java
	 * Package:     com.cg.web.hms.dao
	 * Desc:        Display the Hotel List after Login verification
	 * Version:     2.0
	 * Author: Tanmay Dixit
	 ************************************************************************************/
	public List<Hotels> viewAllHotels() throws HBMSException;
	
	/************************************************************************************
	 * File:        UserDao.java
	 * Package:     com.cg.web.hms.dao
	 * Desc:        Fetching the room list with the help of hotel id 
	 * Version:     1.0
	 * Author: Harsh Bhansali
	 ************************************************************************************/
	public Hotels searchHotelById(int hotelId) throws HBMSException;
	
	/************************************************************************************
	 * File:        UserDao.java
	 * Package:     com.cg.web.hms.dao
	 * Desc:        Filter the hotel list by city
	 * Version:     1.0
	 * Author: Tanmay Dixit
	 ************************************************************************************/
	
	public List<Hotels> searchHotelByCity(String city) throws HBMSException;

}
