package com.cg.web.hms.dao;

import java.util.List;

import com.cg.web.hms.entities.Room;
import com.cg.web.hms.exception.HBMSException;

public interface RoomBookingDao {
	
	/************************************************************************************
	 * File:        RoomBookingDao.java
	 * Package:     com.cg.web.hms.dao
	 * Desc:        Register New User details
	 * Version:     1.0
	 * Author: Harsh Bhansali
	 ************************************************************************************/
	
	public List<Room> getAllRoomDetails(int hotelId) throws HBMSException;

}
