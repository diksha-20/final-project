package com.cg.web.hms.dao;

import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.TypedQuery;
import javax.transaction.Transactional;

import org.springframework.stereotype.Repository;

import com.cg.web.hms.entities.Room;
import com.cg.web.hms.exception.HBMSException;

@Repository
public class RoomBookingDaoImpl implements RoomBookingDao {

	@PersistenceContext
	private EntityManager entityManager;
	
	public EntityManager getEntityManager() {
		return entityManager;
	}

	public void setEntityManager(EntityManager entityManager) {
		this.entityManager = entityManager;
	}

	@Override
	@Transactional
	public List<Room> getAllRoomDetails(int hotelId) throws HBMSException {
		List<Room> rooms;
		
		String sql = "SELECT roomData from Room roomData where roomData.hotelId=?1 AND roomData.avaibility='TRUE'";
		
		TypedQuery<Room> tQuery=entityManager.createQuery(sql,Room.class);
		
		tQuery.setParameter(1, hotelId);
		
		rooms=tQuery.getResultList();
		
		return rooms;
	}

}
