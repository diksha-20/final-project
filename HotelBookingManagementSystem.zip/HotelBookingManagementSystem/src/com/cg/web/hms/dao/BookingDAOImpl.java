package com.cg.web.hms.dao;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.TypedQuery;

import org.springframework.stereotype.Repository;

import com.cg.web.hms.entities.Booking;
import com.cg.web.hms.entities.Room;
import com.cg.web.hms.exception.HBMSException;



@Repository
public class BookingDAOImpl implements BookingDAO {

	@PersistenceContext
	EntityManager entityManager;
	
	public EntityManager getEntityManager() {
		return entityManager;
	}

	public void setEntityManager(EntityManager entityManager) {
		this.entityManager = entityManager;
	}
	

	@Override
	public int addBookingDetails(Booking bookingData) throws HBMSException {
		
		int bookingId = 0;
		
		try
		{
			entityManager.persist(bookingData);
			
			
			bookingId = bookingData.getBookingId();
			
		} 
		catch (Exception e) {
			
			throw new HBMSException("Something went wrong while inserting Booking Details. Reason :"+e.getMessage());
			
		}
		
		
	return bookingId;
	}

	@Override
	public double getRoomAmount(int roomId) throws HBMSException {
		double amount = 0;
		try
		{
			
			String query = "select rooms.ratePerNight from Room rooms where rooms.roomId = :id ";
			
			TypedQuery<Double> tquery = entityManager.createQuery(query, Double.class);
			
			tquery.setParameter("id", roomId);
			
			amount = tquery.getSingleResult();
			
		}
		catch(Exception e){
			
			throw new HBMSException("Something went wrong while getting room amount. Reason :"+e.getMessage());	
			
		}
		return amount;
	}

	
	@Override
	public Booking getBookingDetails(int id) throws HBMSException {
		
		Booking booking = new Booking();
		
		try 
		{

			booking = entityManager.find(Booking.class, id);
			entityManager.flush();

		}
		catch(Exception e) {
			throw new HBMSException("Problem in fetching Booking Details. Reason : "+e.getMessage());

		}
		return booking;
	}

	@Override
	public void changeRoomAvailability(int roomId) throws HBMSException {
		System.out.println(roomId);
		
		Room room=entityManager.find(Room.class, roomId);

				
		room.setAvaibility("FALSE");
		entityManager.merge(room);
		
		
		
	}

}
