package com.cg.web.hms.dao;

import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.TypedQuery;

import org.springframework.stereotype.Repository;

import com.cg.web.hms.entities.Hotels;
import com.cg.web.hms.entities.Users;
import com.cg.web.hms.exception.HBMSException;



@Repository
public class UserDaoImpl implements UserDao{

	@PersistenceContext
	private EntityManager entityManager;
	Users userData;
	Hotels hotelData;
	
	public UserDaoImpl() {
		userData = new Users();
		hotelData = new Hotels();
	}


	public EntityManager getEntityManager() {
		return entityManager;
	}


	public void setEntityManager(EntityManager entityManager) {
		this.entityManager = entityManager;
	}

	
	
	@Override
	public Users validateUser(String username, String password)
			throws HBMSException {
		
		try {
			String sql = "SELECT userData FROM Users userData WHERE userData.username=?1 AND userData.password=?2";
			
			TypedQuery<Users> tQuery = entityManager.createQuery(sql,Users.class);
			
			tQuery.setParameter(1, username);
			tQuery.setParameter(2, password);
			
			userData = tQuery.getSingleResult();
			
			if(userData!=null) {
				return userData;
			}
			
		} catch (Exception e) {
			
			throw new HBMSException(e.getMessage());
			
		}
		return null;
	}


	@Override
	public Users addUser(Users user) throws HBMSException {
		
		entityManager.persist(user);
		
		return user;
	}


	@Override
	public List<Hotels> viewAllHotels() throws HBMSException {
		
		List<Hotels> hotels;
		
		String sql = "SELECT hotelData FROM Hotels hotelData";
		
		TypedQuery<Hotels> tQuery = entityManager.createQuery(sql,Hotels.class);
		
		hotels = tQuery.getResultList();
		
		return hotels;
	}


	@Override
	public Hotels searchHotelById(int hotelId) throws HBMSException {
		
		String sql = "SELECT hotel FROM Hotels hotel WHERE hotel.hotelId=?1";
		
		TypedQuery<Hotels> tQuery = entityManager.createQuery(sql,Hotels.class);
		
		tQuery.setParameter(1, hotelId);
		
		hotelData = tQuery.getSingleResult();
		
		return hotelData;
	}


	@Override
	public List<Hotels> searchHotelByCity(String city) throws HBMSException {
		
		List<Hotels> hotelList;
		
		String sql = "SELECT hotel FROM Hotels hotel WHERE hotel.city=?1";
		
		TypedQuery<Hotels> tQuery = entityManager.createQuery(sql,Hotels.class);
		
		tQuery.setParameter(1, city);
		
		hotelList = tQuery.getResultList();
		
		return hotelList;
	}

}
