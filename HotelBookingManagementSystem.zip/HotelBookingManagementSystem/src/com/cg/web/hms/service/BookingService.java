package com.cg.web.hms.service;

import com.cg.web.hms.entities.Booking;
import com.cg.web.hms.exception.HBMSException;



public interface BookingService {

	/************************************************************************************
	 * File:        BookingService.java
	 * Package:     com.cg.web.hms.service
	 * Desc:        Accept the Booking details from the user
	 * Version:     1.0
	 * Author:      Harsh Bhansali
	 ************************************************************************************/
	public int addBookingDetails(Booking bookingData) throws HBMSException;

	/************************************************************************************
	 * File:        BookingService.java
	 * Package:     com.cg.web.hms.service
	 * Desc:        Fetch the per day amount by RoomId
	 * Version:     1.0
	 * Author:      Shweta Gaikwad
	 ************************************************************************************/
	public double getRoomAmount(int roomId) throws HBMSException;
	
	/************************************************************************************
	 * File:        BookingService.java
	 * Package:     com.cg.web.hms.service
	 * Desc:        Fetch the booking details from Database
	 * Version:     1.0
	 * Author:      Saloni Nagaria
	 ************************************************************************************/
	public Booking getBookingDetails(int id) throws HBMSException;
	
	/************************************************************************************
	 * File:        BookingService.java
	 * Package:     com.cg.web.hms.service
	 * Desc:        Changes the room Availability 
	 * Version:     1.0
	 * Author:      Tanmay Dixit
	 ************************************************************************************/

	public void changeRoomAvailability(int roomId) throws HBMSException;
	
}
