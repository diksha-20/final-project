package com.cg.web.hms.service;

import java.util.List;

import javax.transaction.Transactional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.cg.web.hms.dao.RoomBookingDao;
import com.cg.web.hms.entities.Room;
import com.cg.web.hms.exception.HBMSException;

@Service
public class RoomBookingServiceImpl implements RoomBookingService
{
	@Autowired
	private RoomBookingDao roomDao;
	
	
	
	public RoomBookingDao getRoomDao() {
		return roomDao;
	}



	public void setRoomDao(RoomBookingDao roomDao) {
		this.roomDao = roomDao;
	}



	@Override
	public List<Room> getAllRoomDetails(int hotelId) throws HBMSException {
		
		return roomDao.getAllRoomDetails(hotelId);
	}

}
