package com.cg.web.hms.service;

import java.util.List;

import javax.transaction.Transactional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.cg.web.hms.dao.UserDao;
import com.cg.web.hms.entities.Hotels;
import com.cg.web.hms.entities.Users;
import com.cg.web.hms.exception.HBMSException;

@Service
@Transactional
public class UserServiceImpl implements UserService {

	@Autowired
	private UserDao userDao;
	
	
	public UserDao getUserDao() {
		return userDao;
	}



	public void setUserDao(UserDao userDao) {
		this.userDao = userDao;
	}


	@Override
	public Users validateUser(String username, String password)
			throws HBMSException {
		
		return userDao.validateUser(username, password);
		
	}


	@Override
	public Users addUser(Users user) throws HBMSException {
		
		return userDao.addUser(user);
		
	}



	@Override
	public List<Hotels> viewAllHotels() throws HBMSException {
		return userDao.viewAllHotels();
	}



	@Override
	public Hotels searchHotelById(int hotelId) throws HBMSException {
		return userDao.searchHotelById(hotelId);
	}



	@Override
	public List<Hotels> searchHotelByCity(String city) throws HBMSException {
		return userDao.searchHotelByCity(city);
	}

}
