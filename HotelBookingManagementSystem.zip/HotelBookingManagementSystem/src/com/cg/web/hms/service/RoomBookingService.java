package com.cg.web.hms.service;

import java.util.List;

import com.cg.web.hms.entities.Room;
import com.cg.web.hms.exception.HBMSException;

public interface RoomBookingService 
{
	/************************************************************************************
	 * File:        RoomBookingService.java
	 * Package:     com.cg.web.hms.service
	 * Desc:        Register New User details
	 * Version:     1.0
	 * Author: Harsh Bhansali
	 ************************************************************************************/
	
	public List<Room> getAllRoomDetails(int hotelId) throws HBMSException;
}
