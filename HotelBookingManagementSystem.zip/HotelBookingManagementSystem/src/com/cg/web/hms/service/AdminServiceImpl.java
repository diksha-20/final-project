package com.cg.web.hms.service;

import java.util.List;

import javax.transaction.Transactional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.cg.web.hms.dao.AdminDAO;
import com.cg.web.hms.entities.Hotels;
import com.cg.web.hms.entities.Room;
import com.cg.web.hms.exception.HBMSException;


@Service
@Transactional
public class AdminServiceImpl implements AdminService {

	@Autowired
	AdminDAO adminDao;
	
	
	
	public AdminDAO getAdminDao() {
		return adminDao;
	}

	public void setAdminDao(AdminDAO adminDao) {
		this.adminDao = adminDao;
	}

	@Override
	public int addHotel(Hotels hotel) throws HBMSException {
		return adminDao.addHotel(hotel);
	}

	@Override
	public void updateHotel(Hotels hotel) throws HBMSException {
		adminDao.updateHotel(hotel);
	}

	@Override
	public Hotels deleteHotel(int id) throws HBMSException {
		return adminDao.deleteHotel(id);
		
	}

	@Override
	public Hotels viewHotel(int id) throws HBMSException {
		return adminDao.viewHotel(id);
		
	}

	@Override
	public List<Hotels> viewAllHotels() throws HBMSException {
		return adminDao.viewAllHotels();
	}

	@Override
	public List<Room> getAllRoomDetails(int hotelId) throws HBMSException {
		// TODO Auto-generated method stub
		return adminDao.getAllRoomDetails(hotelId);
	}

	@Override
	public int addRoom(Room room) throws HBMSException {
		// TODO Auto-generated method stub
		return adminDao.addRoom(room);
	}

}