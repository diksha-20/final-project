package com.cg.web.hms.service;

import java.util.List;

import com.cg.web.hms.entities.Hotels;
import com.cg.web.hms.entities.Room;
import com.cg.web.hms.exception.HBMSException;

public interface AdminService {

	/************************************************************************************
	 * File:        AdminService.java
	 * Package:     com.cg.web.hms.service
	 * Desc:        Add Hotel Details  
	 * Version:     1.0
	 * Author:      Aishwarya Roy
	 ************************************************************************************/

	public int addHotel(Hotels hotel) throws HBMSException;
	
	/************************************************************************************
	 * File:        AdminService.java
	 * Package:     com.cg.web.hms.service
	 * Desc:        Update Hotel Details  
	 * Version:     1.0
	 * Author:      Aishwarya Roy
	 ************************************************************************************/

	public void updateHotel(Hotels hotel) throws HBMSException;
	
	/************************************************************************************
	 * File:        AdminService.java
	 * Package:     com.cg.web.hms.service
	 * Desc:        Delete Hotel Details  
	 * Version:     1.0
	 * Author:      Soutam Dutta
	 ************************************************************************************/
	public Hotels deleteHotel(int id) throws HBMSException;
	
	/************************************************************************************
	 * File:        AdminService.java
	 * Package:     com.cg.web.hms.service
	 * Desc:        Fetches Hotel Details  
	 * Version:     1.0
	 * Author:      Soutam Dutta
	 ************************************************************************************/

	public Hotels viewHotel(int id) throws HBMSException;
	
	/************************************************************************************
	 * File:        AdminService.java
	 * Package:     com.cg.web.hms.service
	 * Desc:        Fetch all Hotel Details  
	 * Version:     1.0
	 * Author:      Soutam Dutta
	 ************************************************************************************/

	public List<Hotels> viewAllHotels() throws HBMSException;
	
	/************************************************************************************
	 * File:        AdminService.java
	 * Package:     com.cg.web.hms.service
	 * Desc:        Fetches Room Details as per hotel Id  
	 * Version:     2.0
	 * Author:      Harsh Bhansali
	 ************************************************************************************/

	public List<Room> getAllRoomDetails(int hotelId) throws HBMSException;
	
	/************************************************************************************
	 * File:        AdminService.java
	 * Package:     com.cg.web.hms.service
	 * Desc:        Add Room to the selected Hotel  
	 * Version:     2.0
	 * Author:      Tanmay Dixit
	 ************************************************************************************/

	public int addRoom(Room room) throws HBMSException;
	
}
