package com.cg.web.hms.service;

import javax.transaction.Transactional;





import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.cg.web.hms.dao.BookingDAO;
import com.cg.web.hms.entities.Booking;
import com.cg.web.hms.exception.HBMSException;


@Service
@Transactional
public class BookingServiceImpl implements BookingService {

	@Autowired
	BookingDAO bookingDao;
	
	public BookingDAO getBookingDao() {
		return bookingDao;
	}

	public void setBookingDao(BookingDAO bookingDao) {
		this.bookingDao = bookingDao;
	}

	
	@Override
	public int addBookingDetails(Booking bookingData) throws HBMSException {
		
		return bookingDao.addBookingDetails(bookingData);
	}

	@Override
	public double getRoomAmount(int roomId) throws HBMSException {
		
		return bookingDao.getRoomAmount(roomId);
	}

	
	@Override
	public Booking getBookingDetails(int id) throws HBMSException {
		
		return bookingDao.getBookingDetails(id);
	}

	@Override
	public void changeRoomAvailability(int roomId) throws HBMSException {

        bookingDao.changeRoomAvailability(roomId);
		
	}

}
