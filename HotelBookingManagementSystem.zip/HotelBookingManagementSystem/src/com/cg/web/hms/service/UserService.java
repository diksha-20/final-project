package com.cg.web.hms.service;

import java.util.List;

import com.cg.web.hms.entities.Hotels;
import com.cg.web.hms.entities.Users;
import com.cg.web.hms.exception.HBMSException;

public interface UserService {
	
	/************************************************************************************
	 * File:        UserService.java
	 * Package:     com.cg.web.hms.service
	 * Desc:        Validate the user at the time of Login
	 * Version:     1.0
	 * Author: 		Shweta Gaikwad
	 ************************************************************************************/

	public Users validateUser(String username,String password) throws HBMSException;
	
	/************************************************************************************
	 * File:        UserService.java
	 * Package:     com.cg.web.hms.service
	 * Desc:        Register New User details
	 * Version:     1.0
	 * Author: 		Saloni Nagaria
	 ************************************************************************************/
	public Users addUser(Users user) throws HBMSException;

	
	/************************************************************************************
	 * File:        UserService.java
	 * Package:     com.cg.web.hms.service
	 * Desc:        Display the Hotel List after Login verification
	 * Version:     2.0
	 * Author:		Tanmay Dixit
	 ************************************************************************************/
	public List<Hotels> viewAllHotels() throws HBMSException;
	
	/************************************************************************************
	 * File:        UserService.java
	 * Package:     com.cg.web.hms.service
	 * Desc:        Fetching the room list with the help of hotel id 
	 * Version:     1.0
	 * Author: 		Tanmay Dixit
	 ************************************************************************************/
	public Hotels searchHotelById(int hotelId) throws HBMSException;
	
	/************************************************************************************
	 * File:        UserService.java
	 * Package:     com.cg.web.hms.service
	 * Desc:        Filter the hotel list by city
	 * Version:     1.0
	 * Author: 		Harsh Bhansali
	 ************************************************************************************/
	
	public List<Hotels> searchHotelByCity(String city) throws HBMSException;

}
